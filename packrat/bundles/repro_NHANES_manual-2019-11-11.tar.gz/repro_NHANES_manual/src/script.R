packrat::init()

#packrat::snapshot()
#packrat::bundle()
#packrat::unbundle()
